package com.shoptech.entity;

import java.util.List;

public class SettingBag {

    private List<Setting> listSettings;

    public SettingBag(List<Setting> listSettings) {
        this.listSettings = listSettings;
    }

    public Setting get(String key) {

        // need to implement the hashCode() and equals() method in Setting Class in order to use
        // indexOf() method.
        int index = listSettings.indexOf(new Setting(key));

        // if setting object exist, return the object
        if (index >= 0) {
            return listSettings.get(index);
        }

        return null;
    }

    public String getValue(String key) {
        Setting setting = get(key);

        if (setting != null) {
            return setting.getValue();
        }

        return null;
    }

    public void update(String key, String value) {
        Setting setting = get(key);

        if (setting != null && value != null) {
            setting.setValue(value);
        }

    }

    public List<Setting> list() {
        return listSettings;
    }
}