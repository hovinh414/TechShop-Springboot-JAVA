package com.shoptech.entity;

public enum AuthenticationType {
	DATABASE, GOOGLE, FACEBOOK
}
