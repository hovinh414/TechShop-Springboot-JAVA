package com.shoptech.entity;

public enum PaymentMethod {
    COD, CREDIT_CARD, PAYPAL
}
