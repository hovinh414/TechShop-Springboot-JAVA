package com.shoptech.entity;

public enum OrderStatus {

    NEW {
        @Override
        public String defaultDescription() {
            return "Đơn hàng đã được đặt";
        }

    },

    CANCELLED {
        @Override
        public String defaultDescription() {
            return "Đơn hàng đã bị từ chối";
        }
    },

    PROCESSING {
        @Override
        public String defaultDescription() {
            return "Đơn hàng đang xử lý";
        }
    },

    PACKAGED {
        @Override
        public String defaultDescription() {
            return "Sản phẩm đã được dóng gói";
        }
    },

    PICKED {
        @Override
        public String defaultDescription() {
            return "Shipper đã nhận đơn";
        }
    },

    SHIPPING {
        @Override
        public String defaultDescription() {
            return "Shipper đang trên đường giao";
        }
    },

    DELIVERED {
        @Override
        public String defaultDescription() {
            return "Khách hàng đã nhận đơn hàng";
        }
    },

    RETURN_REQUESTED {
        @Override
        public String defaultDescription() {
            return "Khách hàng gửi yêu cầu trả lại đơn hàng";
        }
    },

    RETURNED {
        @Override
        public String defaultDescription() {
            return "Sản phẩm bị hoàn trả";
        }
    },

    PAID {
        @Override
        public String defaultDescription() {
            return "Khách hàng đã thanh toán đơn hàng";
        }
    },

    REFUNDED {
        @Override
        public String defaultDescription() {
            return "Khách hàng đã được hoàn trả tiền";
        }
    };

    public abstract String defaultDescription();
}
