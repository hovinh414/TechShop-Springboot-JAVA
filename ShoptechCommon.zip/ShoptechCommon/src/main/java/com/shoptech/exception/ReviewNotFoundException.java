package com.shoptech.exception;

public class ReviewNotFoundException extends Exception {

	public ReviewNotFoundException(String message) {
		super(message);
	}	
}
